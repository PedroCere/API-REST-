package com.example.demo.repositories;

import com.example.demo.entities.AuthorEntity;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface AuthorRepository extends CrudRepository<AuthorEntity, Long> {

    // Cambiado para seguir la convención de Spring Data JPA
    Iterable<AuthorEntity> findByAgeLessThan(int age);

    // Usando parámetros nombrados en la consulta con @Query
    @Query("SELECT a FROM AuthorEntity a WHERE a.age > :age")
    Iterable<AuthorEntity> findAuthorsWithAgeGreaterThan(@Param("age") int age);
}

