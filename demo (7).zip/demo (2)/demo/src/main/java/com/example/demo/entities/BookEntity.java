package com.example.demo.entities;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Entity
@Table(name = "books")
public class BookEntity {


    @Id
    private Long isbn;

    private String title;

    @ManyToOne(cascade = CascadeType.ALL,optional = true)
    @JoinColumn(name = "author_id",nullable = true)
    private AuthorEntity author;


}
