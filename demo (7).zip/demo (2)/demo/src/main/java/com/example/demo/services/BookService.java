package com.example.demo.services;

import com.example.demo.entities.BookEntity;

import java.util.List;
import java.util.Optional;

public interface BookService {

    BookEntity createBook(Long isbn, BookEntity book);

    List<BookEntity> findAll();

    Optional<BookEntity> findOne(Long isbn);
}
