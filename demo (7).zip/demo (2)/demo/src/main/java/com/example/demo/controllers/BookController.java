package com.example.demo.controllers;

import com.example.demo.domain.dto.BookDto;
import com.example.demo.entities.BookEntity;
import com.example.demo.mappers.Mapper;
import com.example.demo.services.BookService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@RestController
public class BookController {

    private Mapper<BookEntity,BookDto> bookMapper;

    private BookService bookService;

    public BookController(Mapper<BookEntity, BookDto> bookMapper, BookService bookService) {
        this.bookMapper = bookMapper;
        this.bookService = bookService;
    }

    @PutMapping("/books/{isbn}")
    public ResponseEntity<BookDto> createBook(@PathVariable("isbn")Long isbn,
                                              @RequestBody BookDto bookDto){
     BookEntity bookEntity =  bookMapper.mapFrom(bookDto);
     BookEntity savedBook  =  bookService.createBook(isbn,bookEntity);
     BookDto savedBookDto =  bookMapper.mapTo(savedBook);

     return new ResponseEntity<>(savedBookDto, HttpStatus.CREATED);

    }

    @GetMapping("/books")
    public List<BookDto> listBooks(){

        List<BookEntity> books = bookService.findAll();
        return books.stream()
                .map(bookMapper::mapTo)
                .collect(Collectors.toList());
    }
    @GetMapping(path = "/books/{isbn}")
    public ResponseEntity<BookDto> getBook(@PathVariable("isbn") Long isbn){
        Optional<BookEntity> foundBook = bookService.findOne(isbn);
      return foundBook.map(bookEntity -> {
                BookDto bookDto = bookMapper.mapTo(bookEntity);
                return new ResponseEntity<>(bookDto, HttpStatus.OK);
        }).orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }
}
