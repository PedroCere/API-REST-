package com.example.demo;

import com.example.demo.domain.dto.AuthorDto;
import com.example.demo.domain.dto.BookDto;
import com.example.demo.entities.AuthorEntity;
import com.example.demo.entities.BookEntity;

public class TestDataUtil {

    private TestDataUtil(){

    }


    public static AuthorEntity createTestAuthorA() {
        AuthorEntity authorEntity = AuthorEntity.builder()
                .id(1L)
                .name("Abigail Rose")
                .age(80)
                .build();
        return authorEntity;
    }

    public static AuthorEntity createTestAuthorB() {
        AuthorEntity authorEntity = AuthorEntity.builder()
                .id(2L)
                .name("Pedro Lco")
                .age(44)
                .build();
        return authorEntity;
    }

    public static AuthorEntity createTestAuthorC() {
        AuthorEntity authorEntity = AuthorEntity.builder()
                .id(3L)
                .name("Mario Ñui")
                .age(49)
                .build();
        return authorEntity;
    }

    public static BookEntity createTestBokEntityA(final AuthorEntity authorEntity) {
        return BookEntity.builder()
                .isbn(978-1-2345-43244-0L)
                .title("The shadow in the Attic")
                .author(authorEntity)
                .build();
    }
    public static BookEntity createTestBookB(final AuthorEntity authorEntity) {
        return BookEntity.builder()
                .isbn(111-1-5454-7654L)
                .title("The shadow in the Attic")
                .author(authorEntity)
                .build();
    }
    public static BookEntity createTestBookC(final AuthorEntity authorEntity) {
        return BookEntity.builder()
                .isbn(5651-0-0004-3332L)
                .title("The shadow in the Attic")
                .author(authorEntity)
                .build();
    }
    public static BookDto createTestBookDtoA(final AuthorDto author) {
        return BookDto.builder()
                .isbn(111-1-5454-7654L)
                .title("The shadow in the Attic")
                .author(author)
                .build();
    }



}
